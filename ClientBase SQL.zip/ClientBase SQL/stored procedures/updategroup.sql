DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updategroup`(
	in pgroupid mediumint(9),
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
    
    UPDATE
		groups
	SET
        detail = pdetail
	WHERE
		id = pgroupid;
        
	call insertauditlog("UPDATE","groups",pgroupid,pusername,pdetail);
    
END$$
DELIMITER ;
