DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectclient`(
	in pclientid mediumint(9),
    in pusername nvarchar(160)
)
BEGIN

	SELECT
		cl.id as `clientid`,
		ct.businessname,
		ct.title1,
		ct.forename1,
		ct.middlename1,
		ct.surname1,
		ct.title2,
		ct.forename2,
		ct.middlename2,
		ct.surname2,
		ct.address11,
		ct.address12,
		ct.address13,
		ct.address14,
		ct.address15,
		ct.postcode1,
		ct.address21,
		ct.address22,
		ct.address23,
		ct.address24,
		ct.address25,
		ct.postcode2,
		ct.phonehome1,
		ct.phonework1,
		ct.phonemobile1,
		ct.phonehome2,
		ct.phonework2,
		ct.phonemobile2,
		ct.email11,
		ct.email12,
		ct.email21,
		ct.email22,
		ct.coname,
		ct.coaddress1,
		ct.coaddress2,
		ct.coaddress3,
		ct.coaddress4,
		ct.coaddress5,
		ct.copostcode,
		ct.cophonehome,
		ct.cophonework,
		ct.cophonemobile,
		ct.coemail1,
		ct.coemail2
	FROM 
		clients as cl
    INNER JOIN
		contacts as ct on cl.contactsid = ct.id
	WHERE 
		cl.id = pclientid AND
        cl.active=true;
        
	call insertauditlog("READ","clients/contacts",pclientid,pusername,'client');
END$$
DELIMITER ;
