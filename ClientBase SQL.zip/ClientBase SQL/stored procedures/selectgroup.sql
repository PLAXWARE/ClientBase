DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectgroup`(
	in pgroupid mediumint(9),
    in pusername nvarchar(160)
)
BEGIN

	SELECT
		id,
        detail,
        active
    FROM 
		groups
	WHERE 
		groupid = pgroupid AND
        active=true;
	
	call insertauditlog("READ","groups",pgroupid,pusername,'groups');
END$$
DELIMITER ;
