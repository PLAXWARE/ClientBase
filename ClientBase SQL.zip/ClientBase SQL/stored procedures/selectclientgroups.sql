DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectclientgroups`(
	in pclientid mediumint(9),
    in pusername nvarchar(160)
)
BEGIN

	SELECT
		g.id,
        g.detail,
        g.active
	FROM
		groupmember as gm
	INNER JOIN
		groups as g on gm.groupid = g.id
	WHERE 
		cl.clientid = pclientid AND
        cl.active=true;
           
	call insertauditlog("READ","clients/groups",pclientid,pusername,'clientgroups');
END$$
DELIMITER ;
