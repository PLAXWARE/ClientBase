DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertclienttype`(
	out newid mediumint(9),
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
	   
    DECLARE CtID mediumint(9) default 0;
    
    INSERT INTO 
		clienttypes
		(
        detail
		)
	VALUES
		(
        pdetail
        );

	SET CtID = Last_Insert_ID();
 
	SELECT CtID INTO newid;
    
    call insertauditlog("INSERT","clienttypes",CtID,pusername,pdetail);
    
END$$
DELIMITER ;
