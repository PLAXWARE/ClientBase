DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectclientssearch`(
	in psearchstring nvarchar(255)
)
BEGIN

	SELECT
		cl.id as `clientid`,
		ct.businessname,
		ct.title1,
		ct.forename1,
		ct.middlename1,
		ct.surname1,
		ct.title2,
		ct.forename2,
		ct.middlename2,
		ct.surname2,
		ct.address11,
		ct.address12,
		ct.address13,
		ct.address14,
		ct.address15,
		ct.postcode1,
		ct.address21,
		ct.address22,
		ct.address23,
		ct.address24,
		ct.address25,
		ct.postcode2,
		ct.phonehome1,
		ct.phonework1,
		ct.phonemobile1,
		ct.phonehome2,
		ct.phonework2,
		ct.phonemobile2,
		ct.email11,
		ct.email12,
		ct.email21,
		ct.email22,
		ct.coname,
		ct.coaddress1,
		ct.coaddress2,
		ct.coaddress3,
		ct.coaddress4,
		ct.coaddress5,
		ct.copostcode,
		ct.cophonehome,
		ct.cophonework,
		ct.cophonemobile,
		ct.coemail1,
		ct.coemail2
	FROM 
		clients as cl
    INNER JOIN
		contacts as ct on cl.contactsid = ct.id
	WHERE 
		(ct.businessname like psearchstring or
		ct.title1 like psearchstring or
		ct.forename1 like psearchstring or
		ct.middlename1 like psearchstring or
		ct.surname1 like psearchstring or
		ct.title2 like psearchstring or
		ct.forename2 like psearchstring or
		ct.middlename2 like psearchstring or
		ct.surname2 like psearchstring or
		ct.address11 like psearchstring or
		ct.address12 like psearchstring or
		ct.address13 like psearchstring or
		ct.address14 like psearchstring or
		ct.address15 like psearchstring or
		ct.postcode1 like psearchstring or
		ct.address21 like psearchstring or
		ct.address22 like psearchstring or
		ct.address23 like psearchstring or
		ct.address24 like psearchstring or
		ct.address25 like psearchstring or
		ct.postcode2 like psearchstring or
		ct.phonehome1 like psearchstring or
		ct.phonework1 like psearchstring or
		ct.phonemobile1 like psearchstring or
		ct.phonehome2 like psearchstring or
		ct.phonework2 like psearchstring or
		ct.phonemobile2 like psearchstring or
		ct.email11 like psearchstring or
		ct.email12 like psearchstring or
		ct.email21 like psearchstring or
		ct.email22 like psearchstring or
		ct.coname like psearchstring or
		ct.coaddress1 like psearchstring or
		ct.coaddress2 like psearchstring or
		ct.coaddress3 like psearchstring or
		ct.coaddress4 like psearchstring or
		ct.coaddress5 like psearchstring or
		ct.copostcode like psearchstring or
		ct.cophonehome like psearchstring or
		ct.cophonework like psearchstring or
		ct.cophonemobile like psearchstring or
		ct.coemail1 like psearchstring or
		ct.coemail2 like psearchstring) AND
        cl.active=true;
           
END$$
DELIMITER ;
