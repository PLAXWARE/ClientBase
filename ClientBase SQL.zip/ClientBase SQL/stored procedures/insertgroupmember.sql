DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertgroupmember`(
	out newid mediumint(9),
    in pgroupid mediumint(9),
	in pclientid mediumint(9),
    in pusername nvarchar(160)
)
BEGIN
	   
    DECLARE CtID mediumint(9) default 0;
    DECLARE datastring longtext;
    
    INSERT INTO 
		detail
		(
        detail
		)
	VALUES
		(
        pdetail
        );

	SET CtID = Last_Insert_ID();
 
	SELECT CtID INTO newid;
    
    SET datastring = concat_ws(',',cast(pgroupid as char),cast(pclientid as char));
    
    call insertauditlog("INSERT","groupmember",CtID,pusername,datastring);
    
END$$
DELIMITER ;
