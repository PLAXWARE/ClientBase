DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectallgroups`(in pusername nvarchar(160))
BEGIN

	SELECT
		id,
        detail,
        active
    FROM 
		groups
	WHERE 
        active=true;
	
    call insertauditlog("READ","groups",0,pusername,'allgroups');
END$$
DELIMITER ;
