DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatelookupcategory`(
	in plookupcategoryid mediumint(9),
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
    
    UPDATE
		lookupcategorys
	SET
        detail = pdetail
	WHERE
		id = plookupcategoryid;
        
	call insertauditlog("UPDATE","lookupcategory",plookupcategoryid,pusername,pdetail);
    
END$$
DELIMITER ;
