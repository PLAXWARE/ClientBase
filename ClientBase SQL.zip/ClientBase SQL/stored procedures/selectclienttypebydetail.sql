DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectclienttypebydetail`(
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN

	SELECT
		id,
        detail,
        active
	FROM
		clienttypes
	WHERE
		detail = pdetail and
        active=true;
        
	call insertauditlog("READ","clientstypes",0,pusername,pdetail);
END$$
DELIMITER ;
