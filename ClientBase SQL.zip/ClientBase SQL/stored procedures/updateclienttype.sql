DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateclienttype`(
	in pclienttypeid mediumint(9),
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
    
    UPDATE
		clienttypes
	SET
        detail = pdetail
	WHERE
		id = pclienttypeid;
        
	call insertauditlog("UPDATE","clienttypes",pclienttypeid,pusername,pdetail);
    
END$$
DELIMITER ;
