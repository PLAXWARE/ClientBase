DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatelookup`(
	in plookupid mediumint(9),
    in plookupcategoryid mediumint(9),
	in pdetail nvarchar(160),
    in plinecolor int,
    in pactive bit,
    in pusername nvarchar(160)
)
BEGIN

    DECLARE datastring longtext default '';
    
    UPDATE 
		lookups
	SET
        lookupcategoryid = plookupcategoryid,
        detail = pdetail,
        linecolor = plinecolor,
        active = pactive
	WHERE id = plookupid;
    
    SET datastring = concat_ws(',',cast(plookupcategoryid as char),pdetail,cast(plinecolor as char),cast(pactive as char));
    
    call insertauditlog("UPDATE","lookups",plookupid,pusername,datastring);
END$$
DELIMITER ;
