DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateclient`(
	in pclientid mediumint(9),
    in pclienttypeid mediumint(9),
	in pbusinessname nvarchar(160),
	in ptitle1 nvarchar(20),
	in pforename1 nvarchar(160),
	in pmiddlename1 nvarchar(160),
    in psurname1 nvarchar(160),
	in ptitle2 nvarchar(20),
	in pforename2 nvarchar(160),
	in pmiddlename2 nvarchar(160),
    in psurname2 nvarchar(160),
    in paddress11 nvarchar(160),
    in paddress12 nvarchar(160),
    in paddress13 nvarchar(160),
    in paddress14 nvarchar(160),
    in paddress15 nvarchar(160),
    in ppostcode1 nvarchar(20),
	in paddress21 nvarchar(160),
    in paddress22 nvarchar(160),
    in paddress23 nvarchar(160),
    in paddress24 nvarchar(160),
    in paddress25 nvarchar(160),
    in ppostcode2 nvarchar(20),
    in pphonehome1 nvarchar(20),
    in pphonework1 nvarchar(20),
    in pphonemobile1 nvarchar(20),
    in pphonehome2 nvarchar(20),
    in pphonework2 nvarchar(20),
    in pphonemobile2 nvarchar(20),
    in pemail11 nvarchar(255),
    in pemail12 nvarchar(255),
    in pemail21 nvarchar(255),
    in pemail22 nvarchar(255),
    in pconame nvarchar(160),
	in pcoaddress1 nvarchar(160),
    in pcoaddress2 nvarchar(160),
    in pcoaddress3 nvarchar(160),
    in pcoaddress4 nvarchar(160),
    in pcoaddress5 nvarchar(160),
    in pcopostcode nvarchar(20),
    in pcophonehome nvarchar(20),
    in pcophonework nvarchar(20),
    in pcophonemobile nvarchar(20),
    in pcoemail1 nvarchar(255),
    in pcoemail2 nvarchar(255),
    in username nvarchar(100)
)
BEGIN

    DECLARE ConID mediumint(9) default 0;
    DECLARE datastring longtext;
    
    Update 
		clients
	SET
        clienttypeid = pclienttypeid
    WHERE
		ID = pclientid;

	SELECT contactid INTO ConID FROM clients WHERE ID = pclientid;
    
    UPDATE
		contacts
	SET
		businessname = pbusinessname,
		title1 = ptitle1,
		forename1 = pforename1,
		middlename1 = pmiddlename1,
		surname1 = psurname1,
		title2 = ptitle2,
		forename2 = pforename2,
		middlename2 = middlename2,
		surname2 = psurname2,
		address11 = paddress11,
		address12 = paddress12,
		address13 = paddress13,
		address14 = paddress14,
		address15 = paddress15,
		postcode1 = ppostcode1,
		address21 = paddress21,
		address22 = paddress22,
		address23 = paddress23,
		address24 = paddress24,
		address25 = paddress25,
		postcode2 = ppostcode2,
		phonehome1 = pphonehome1,
		phonework1 = pphonework1,
		phonemobile1 = pphonemobile1,
		phonehome2 = pphonehome2,
		phonework2 = pphonework2,
		phonemobile2 = pphonemobile2,
		email11 = pemail11,
		email12 = pemail12,
		email21 = pemail21,
		email22 = pemail22,
		coname = pconame,
		coaddress1 = pcoaddress1,
		coaddress2 = pcoaddress2,
		coaddress3 = pcoaddress3,
		coaddress4 = pcoaddress4,
		coaddress5 = pcoaddress5,
		copostcode = pcopostcode,
		cophonehome = pcophonehome,
		cophonework = pcophonework,
		cophonemobile = pcophonemobile,
		coemail1 = pcoemail1,
		coemail2 = coemail2
	WHERE 
		ID = ConID;
         
    SET datastring = cast(pclienttypeid as char);
    
    call insertauditlog("UPDATE","clients",pclientid,pusername,datastring);
    
    SET datastring = concat_ws(',',
		pbusinessname,
		ptitle1,
		pforename1,
		pmiddlename1,
		psurname1,
		ptitle2,
		pforename2,
		pmiddlename2,
		psurname2,
		paddress11,
		paddress12,
		paddress13,
		paddress14,
		paddress15,
		ppostcode1,
		paddress21,
		paddress22,
		paddress23,
		paddress24,
		paddress25,
		ppostcode2,
		pphonehome1,
		pphonework1,
		pphonemobile1,
		pphonehome2,
		pphonework2,
		pphonemobile2,
		pemail11,
		pemail12,
		pemail21,
		pemail22,
		pconame,
		pcoaddress1,
		pcoaddress2,
		pcoaddress3,
		pcoaddress4,
		pcoaddress5,
		pcopostcode,
		pcophonehome,
		pcophonework,
		pcophonemobile,
		pcoemail1,
		pcoemail2
        );
        
    call insertauditlog("UPDATE","contacts",CnonID,pusername,datastring);
END$$
DELIMITER ;
