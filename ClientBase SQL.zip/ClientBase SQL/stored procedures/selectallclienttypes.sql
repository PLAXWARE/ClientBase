DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectallclienttypes`(in pusername nvarchar(160))
BEGIN

	SELECT
		id,
        detail,
        active
	FROM
		clienttypes
	WHERE
		active=true;
        
	call insertauditlog("READ","clientstype",0,pusername,'allclienttypes');
        
END$$
DELIMITER ;
