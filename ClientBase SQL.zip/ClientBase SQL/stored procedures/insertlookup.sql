DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlookup`(
	out newid mediumint(9),
    in plookupcategoryid mediumint(9),
	in pdetail nvarchar(160),
    in plinecolor int,
    in pactive bit,
    in pusername nvarchar(160)
)
BEGIN
	DECLARE nid mediumint(9) default 0;
    DECLARE datastring longtext default '';
    
    INSERT INTO 
		lookups
        (
        lookupcategoryid,
        detail,
        linecolor,
        active
        )
	VALUES
		(
        plookupcategoryid,
        pdetail,
        plinecolor,
        pactive
        );
	
    SET nid = last_insert_id();
    
    SET datastring = concat_ws(',',cast(plookupcategoryid as char),pdetail,cast(plinecolor as char),cast(pactive as char));
    
    call insertauditlog("INSERT","lookups",nid,pusername,datastring);
END$$
DELIMITER ;
