DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertclient`(
	out newid mediumint(9),
    in pclienttypeid mediumint(9),
	in pbusinessname nvarchar(160),
	in ptitle1 nvarchar(20),
	in pforename1 nvarchar(160),
	in pmiddlename1 nvarchar(160),
    in psurname1 nvarchar(160),
	in ptitle2 nvarchar(20),
	in pforename2 nvarchar(160),
	in pmiddlename2 nvarchar(160),
    in psurname2 nvarchar(160),
    in paddress11 nvarchar(160),
    in paddress12 nvarchar(160),
    in paddress13 nvarchar(160),
    in paddress14 nvarchar(160),
    in paddress15 nvarchar(160),
    in ppostcode1 nvarchar(20),
	in paddress21 nvarchar(160),
    in paddress22 nvarchar(160),
    in paddress23 nvarchar(160),
    in paddress24 nvarchar(160),
    in paddress25 nvarchar(160),
    in ppostcode2 nvarchar(20),
    in pphonehome1 nvarchar(20),
    in pphonework1 nvarchar(20),
    in pphonemobile1 nvarchar(20),
    in pphonehome2 nvarchar(20),
    in pphonework2 nvarchar(20),
    in pphonemobile2 nvarchar(20),
    in pemail11 nvarchar(255),
    in pemail12 nvarchar(255),
    in pemail21 nvarchar(255),
    in pemail22 nvarchar(255),
    in pconame nvarchar(160),
	in pcoaddress1 nvarchar(160),
    in pcoaddress2 nvarchar(160),
    in pcoaddress3 nvarchar(160),
    in pcoaddress4 nvarchar(160),
    in pcoaddress5 nvarchar(160),
    in pcopostcode nvarchar(20),
    in pcophonehome nvarchar(20),
    in pcophonework nvarchar(20),
    in pcophonemobile nvarchar(20),
    in pcoemail1 nvarchar(255),
    in pcoemail2 nvarchar(255),
    in pusername nvarchar(100)
)
BEGIN
	   
    DECLARE CntID mediumint(9) default 0;
    DECLARE ConID mediumint(9) default 0;
    DECLARE datastring longtext default'';
    
    INSERT INTO 
		clients
		(
        clienttypeid
		)
	VALUES
		(
        pclienttypeid
        );

	SET CntID = Last_Insert_ID();
    
    INSERT INTO
		contacts
        (
		businessname,
		title1,
		forename1,
		middlename1,
		surname1,
		title2,
		forename2,
		middlename2,
		surname2,
		address11,
		address12,
		address13,
		address14,
		address15,
		postcode1,
		address21,
		address22,
		address23,
		address24,
		address25,
		postcode2,
		phonehome1,
		phonework1,
		phonemobile1,
		phonehome2,
		phonework2,
		phonemobile2,
		email11,
		email12,
		email21,
		email22,
		coname,
		coaddress1,
		coaddress2,
		coaddress3,
		coaddress4,
		coaddress5,
		copostcode,
		cophonehome,
		cophonework,
		cophonemobile,
		coemail1,
		coemail2
        )
	VALUES
		(
		pbusinessname,
		ptitle1,
		pforename1,
		pmiddlename1,
		psurname1,
		ptitle2,
		pforename2,
		pmiddlename2,
		psurname2,
		paddress11,
		paddress12,
		paddress13,
		paddress14,
		paddress15,
		ppostcode1,
		paddress21,
		paddress22,
		paddress23,
		paddress24,
		paddress25,
		ppostcode2,
		pphonehome1,
		pphonework1,
		pphonemobile1,
		pphonehome2,
		pphonework2,
		pphonemobile2,
		pemail11,
		pemail12,
		pemail21,
		pemail22,
		pconame,
		pcoaddress1,
		pcoaddress2,
		pcoaddress3,
		pcoaddress4,
		pcoaddress5,
		pcopostcode,
		pcophonehome,
		pcophonework,
		pcophonemobile,
		pcoemail1,
		pcoemail2
        );
        
	SET ConID = Last_Insert_ID();
    
	UPDATE clients 
	SET 
		contactid = ConID
	WHERE
		id = CntID;
			
	SET CntID = Last_Insert_ID();
		
	SELECT CntID INTO newid;
    
    SET datastring = cast(pclienttypeid as char);
    
    call insertauditlog("INSERT","clients",CntID,pusername,datastring);
    
    SET datastring = concat_ws(',',
		pbusinessname,
		ptitle1,
		pforename1,
		pmiddlename1,
		psurname1,
		ptitle2,
		pforename2,
		pmiddlename2,
		psurname2,
		paddress11,
		paddress12,
		paddress13,
		paddress14,
		paddress15,
		ppostcode1,
		paddress21,
		paddress22,
		paddress23,
		paddress24,
		paddress25,
		ppostcode2,
		pphonehome1,
		pphonework1,
		pphonemobile1,
		pphonehome2,
		pphonework2,
		pphonemobile2,
		pemail11,
		pemail12,
		pemail21,
		pemail22,
		pconame,
		pcoaddress1,
		pcoaddress2,
		pcoaddress3,
		pcoaddress4,
		pcoaddress5,
		pcopostcode,
		pcophonehome,
		pcophonework,
		pcophonemobile,
		pcoemail1,
		pcoemail2
        );
        
    call insertauditlog("INSERT","contacts",CnonID,pusername,datastring);
    
END$$
DELIMITER ;
