DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertgroup`(
	out newid mediumint(9),
	in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
	   
    DECLARE CtID mediumint(9) default 0;
    
    INSERT INTO 
		detail
		(
        detail
		)
	VALUES
		(
        pdetail
        );

	SET CtID = Last_Insert_ID();
 
	SELECT CtID INTO newid;
    
    call insertauditlog("INSERT","groups",CtID,pusername,pdetail);
END$$
DELIMITER ;
