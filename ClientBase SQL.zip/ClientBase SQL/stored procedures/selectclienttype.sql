DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectclienttype`(
	pclienttypeid mediumint(9),
    in pusername nvarchar(160)
)
BEGIN

	SELECT
		id,
        detail,
        active
	FROM
		clienttypes
	WHERE
		id = pclienttypeid and
        active=true;
	
	call insertauditlog("READ","clienttypes",pclienttypeid,pusername,'clienttype');
END$$
DELIMITER ;
