DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlookupcategory`(
	out newid mediumint(9),
    in pdetail nvarchar(160),
    in pusername nvarchar(160)
)
BEGIN
	DECLARE nid mediumint(9) default 0;
    
    INSERT INTO
		lookupcategorys
        (
        detail
        )
	VALUES
		(
        pdetail
        );
        
	SET nid = last_insert_id();
    
    call insertauditlog("INSERT","lookupcategorys",nid,pusername,pdetail);
	
    SET newid = nid;
END$$
DELIMITER ;
