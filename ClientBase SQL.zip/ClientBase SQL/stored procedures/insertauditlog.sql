DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertauditlog`(
    in paction nvarchar(100),
    in ptablename nvarchar(100),
    in piableid mediumint(9),
    in pusername nvarchar(100),
    in pactiondata longtext
)
BEGIN
    INSERT INTO
		`auditlog`
		(
        `action`,
        tablename,
        tableid,
        username,
        actiondata,
        actiondate
        )
	VALUES
    (
        paction,
        ptablename,
        ptableid,
        pusername,
        pactiondata,
        current_timestamp());

END$$
DELIMITER ;
