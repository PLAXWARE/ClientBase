CREATE TABLE `lookups` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT b'1',
  `lookupcategoryid` mediumint(9) DEFAULT '0',
  `detail` varchar(160) CHARACTER SET utf8 NOT NULL,
  `linecolor` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
