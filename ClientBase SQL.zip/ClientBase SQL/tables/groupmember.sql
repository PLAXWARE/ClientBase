CREATE TABLE `groupmember` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT b'1',
  `groupid` mediumint(9) NOT NULL,
  `clientid` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
