CREATE TABLE `clients` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `clientypeid` mediumint(9) NOT NULL,
  `contactid` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
