CREATE TABLE `auditlog` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tablename` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tableid` mediumint(9) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `actiondata` longtext,
  `actiondate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
